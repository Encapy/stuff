# stuff
just some stuff for learning/training
